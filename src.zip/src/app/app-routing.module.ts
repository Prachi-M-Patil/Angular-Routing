import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FirstComponent } from './first/first.component';
import { SecondComponent } from './second/second.component';
import { ThirdComponent } from './third/third.component';
import { NotfoundComponent } from './notfound/notfound.component';
import { ProductComponent } from './product/product.component';

const routes: Routes = [
  {path:'first', component: FirstComponent } ,
  {path:'second', component: SecondComponent } ,
  {path:'', redirectTo: 'first' , pathMatch:'full' } ,

  { path: '**', component: NotfoundComponent } ,// Wildcard route for 404 page,

  {path: 'product/:id', component: ProductComponent},
  {path: 'user', loadChildren:()=> import('./user/user.module').then(m=>m.UserModule)}





];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
