import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-product',
  standalone: false,
  
  templateUrl: './product.component.html',
  styleUrl: './product.component.css'
})
export class ProductComponent {
  productId: number = 0;

  constructor(private route: ActivatedRoute){

  }

  ngOnInit(){
    this.productId = Number(this.route.snapshot.paramMap.get('id'));
  }

  /*ngOnInit(){
    this.route.paramMap.subscribe(params => {
      this.productId = Number(params.get('id'));
    });
  }
*/

}
