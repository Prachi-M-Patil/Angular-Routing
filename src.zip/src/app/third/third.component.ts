import { Component } from '@angular/core';

@Component({
  selector: 'app-third',
  standalone: false,
  
  templateUrl: './third.component.html',
  styleUrl: './third.component.css'
})
export class ThirdComponent {

}
